# Petinder Next.js Project
This is the scaffold.
