# Petinder - Next.js Bilingual Scaffold (EN/ES)
Slogan: "Adopt, love and discover" / "Adopta, ama y descubre"

## What this repo contains
- Minimal Next.js App Router scaffold (app/)
- Two language routes: /en and /es (separate paths, good for SEO)
- Admin placeholder at /admin
- Supabase client placeholder (lib/supabaseClient.js)
- NextAuth placeholder route (app/api/auth/route.js)
- server.js to run Next.js as a Node app (for Hostinger Business)
- .env.example with required env vars
- SQL file with basic tables for Supabase
- README contains step-by-step deploy instructions for Vercel and Hostinger

## Quick start (local)
1. Copy `.env.example` to `.env.local` and fill values.
2. `npm install`
3. `npm run dev` (development)

## Build & run (production)
1. `npm run build`
2. `npm run start` (runs server.js wrapper)

## Hostinger (Business) hints
- Upload this project to `public_html/pet2/` or deploy via Git if Hostinger Git is enabled.
- If using Hostinger Node.js application, point it to `server.js` in `public_html/pet2`.
- Alternatively, run `npm run export` and upload `/out` to the subdomain folder for a static site.

## Vercel
- Connect your GitHub repo to Vercel and deploy (Next.js is auto-detected).
- Add domain `pet2.petinder.online` to project and follow Vercel DNS instructions.

## Supabase
- Use the `supabase/schema.sql` file to create basic tables.

## Notes
- This scaffold uses placeholders for AI integration (OpenAI). Add your keys and implement endpoints in `app/api/ai/`.
- The code is intentionally minimal to be easy to extend.
