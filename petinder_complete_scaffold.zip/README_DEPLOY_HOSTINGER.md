Hostinger deployment (Business plan) - quick guide:

Option A - Run as Node.js app (preferred for dynamic Next.js):
1. Upload project folder to public_html/pet2/ using File Manager or SFTP.
2. Ensure package.json exists and node_modules will be installed.
3. Use SSH:
   cd public_html/pet2
   npm install --production
   npm run build
4. In Hostinger panel -> Sitios web -> petinder.online -> Aplicaciones / Node.js -> Create app:
   - Path: /public_html/pet2
   - Start file: server.js
   - Node version: 18.x
5. Start app. Visit https://pet2.petinder.online

Option B - Static export:
1. On your dev machine:
   npm install
   npm run build
   npm run export
2. Upload the `out` folder contents to public_html/pet2/
3. Visit https://pet2.petinder.online

Notes:
- For Supabase, set environment variables in your deployment or .env.local
- For automatic deploys, use Git integration in Hostinger (if enabled)
