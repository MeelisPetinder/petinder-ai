import { supabase } from '../../../lib/supabaseClient'
export default async function Pets() {
  // Placeholder - fetch pets from Supabase in real implementation
  return (
    <div>
      <h3>Available pets (EN)</h3>
      <p>(Demo list) Max, Luna</p>
    </div>
  )
}
