export default function EnHome() {
  return (
    <div>
      <h2>Adopt, love and discover</h2>
      <p>Welcome to Petinder (EN) — find your new family member.</p>
      <a href="/en/pets">See pets</a>
    </div>
  )
}
