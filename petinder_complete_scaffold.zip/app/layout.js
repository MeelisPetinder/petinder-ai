import './globals.css'

export const metadata = {
  title: 'Petinder - Adopt, love and discover',
  description: 'Portal de adopción bilingüe'
}

export default function RootLayout({ children }) {
  return (
    <html lang='en'>
      <body>
        <header style={{padding:20, background:'#f7f1ff'}}>
          <a href="/en">EN</a> | <a href="/es">ES</a>
          <h1>Adopt, love and discover / Adopta, ama y descubre</h1>
        </header>
        <main style={{padding:20}}>{children}</main>
        <footer style={{padding:20, marginTop:40, borderTop:'1px solid #eee'}}>© Petinder</footer>
      </body>
    </html>
  )
}
