// Placeholder NextAuth route for App Router.
// Replace with real NextAuth or Supabase Auth implementation.
export async function GET(req) {
  return new Response(JSON.stringify({ message: 'Auth placeholder' }), { status: 200 })
}
