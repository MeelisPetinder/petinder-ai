import { redirect } from 'next/navigation'
export default function Home() {
  // Redirect to Spanish root by default
  redirect('/es')
}
