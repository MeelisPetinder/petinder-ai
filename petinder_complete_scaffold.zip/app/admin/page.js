export default function AdminDashboard() {
  return (
    <div>
      <h2>Admin - Super Admin</h2>
      <p>From here you'll manage shelters, pets, content and approvals.</p>
    </div>
  )
}
