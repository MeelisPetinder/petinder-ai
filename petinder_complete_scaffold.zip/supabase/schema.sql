-- Basic schema for Supabase
create extension if not exists "pgcrypto";

create table users (
  id uuid primary key default gen_random_uuid(),
  email text unique not null,
  name text,
  role text default 'user',
  created_at timestamptz default now()
);

create table shelters (
  id uuid primary key default gen_random_uuid(),
  owner uuid references users(id),
  name text,
  description text,
  status text default 'pending',
  created_at timestamptz default now()
);

create table pets (
  id uuid primary key default gen_random_uuid(),
  shelter_id uuid references shelters(id),
  name text,
  species text,
  breed text,
  age text,
  size text,
  photo text,
  description text,
  status text default 'available',
  created_at timestamptz default now()
);

create table places (
  id uuid primary key default gen_random_uuid(),
  created_by uuid references users(id),
  name text,
  category text,
  latitude float,
  longitude float,
  description text,
  photo text,
  created_at timestamptz default now()
);
